import { getAIProvider } from "@/lib/ai/provider";
import { levels, validatePattern, type Actuator, type CustomPattern, type Level, type PatternStep } from "@/lib/demo-data";

type PatternRequest = {
  goal: string;
  timeOfDay?: string;
  duration: number;
  level: Level;
  recentSessions?: string[];
  feedback?: { sessionName: string; rating: number; comfort?: string }[];
  request?: string;
};

function isRequest(value: unknown): value is PatternRequest {
  if (!value || typeof value !== "object") return false;
  const item = value as Partial<PatternRequest>;
  return typeof item.goal === "string" && item.goal.trim().length > 0 && [5, 10, 15, 20].includes(item.duration || 0) && ["Gentle", "Balanced", "Strong"].includes(item.level || "") && (item.request === undefined || typeof item.request === "string");
}

function fallback(body: PatternRequest): CustomPattern {
  const intensity = levels[body.level];
  const step = (amplitude: number, durationBeats: number): PatternStep => ({ amplitude: Math.max(0, amplitude), durationBeats });
  return validatePattern({
    name: `${body.goal[0].toUpperCase()}${body.goal.slice(1)} Rhythm`,
    goal: body.goal,
    objective: `Support a ${body.goal} Session with a measured three-point Rhythm.`,
    duration: body.duration,
    intensity,
    level: body.level,
    why: `Built because you selected ${body.goal}, ${body.duration} minutes, and the ${body.level} level.`,
    timingUnitMs: 10,
    pauseMs: 1_000,
    loopCount: Math.max(1, Math.floor((body.duration * 60_000) / 3_000)),
    source: "ai",
    tracks: [
      { actuator: "P6", steps: [step(intensity, 100), step(intensity - 5, 100)] },
      { actuator: "LU9", steps: [step(intensity - 8, 100), step(intensity, 100)] },
      { actuator: "H7", steps: [step(intensity - 5, 100), step(intensity - 10, 100)] },
    ],
  });
}

function normalizeSteps(value: unknown): PatternStep[] | null {
  if (!Array.isArray(value) || value.length === 0 || value.length > 40) return null;
  const steps = value.map((step) => {
    if (!step || typeof step !== "object") return null;
    const item = step as Partial<PatternStep>;
    if (!Number.isInteger(item.amplitude) || !Number.isInteger(item.durationBeats)) return null;
    return { amplitude: item.amplitude as number, durationBeats: item.durationBeats as number };
  });
  return steps.every((step): step is PatternStep => step !== null) ? steps : null;
}

function normalizeModelPattern(value: unknown, body: PatternRequest): CustomPattern {
  if (!value || typeof value !== "object") throw new Error("Malformed pattern");
  const item = value as Partial<CustomPattern>;
  if (!Array.isArray(item.tracks) || item.tracks.length !== 3) throw new Error("Malformed tracks");
  const tracks = item.tracks.map((track, index) => {
    const expected = (["P6", "LU9", "H7"] as Actuator[])[index];
    if (!track || track.actuator !== expected) throw new Error("Unsupported actuator mapping");
    const steps = normalizeSteps(track.steps);
    if (!steps) throw new Error("Malformed Steps");
    return { actuator: expected, steps };
  });
  return validatePattern({
    name: typeof item.name === "string" ? item.name : "",
    goal: body.goal,
    objective: typeof item.objective === "string" ? item.objective : "",
    duration: body.duration,
    intensity: typeof item.intensity === "number" ? item.intensity : levels[body.level],
    level: body.level,
    why: typeof item.why === "string" ? item.why : "",
    timingUnitMs: item.timingUnitMs === 10 ? 10 : (() => { throw new Error("Unsupported timing unit"); })(),
    pauseMs: item.pauseMs as number,
    loopCount: item.loopCount as number,
    source: "ai",
    tracks,
  });
}

export async function POST(request: Request) {
  let body: unknown;
  try {
    body = await request.json();
  } catch {
    return Response.json({ error: "Please try that pattern request again." }, { status: 400 });
  }
  if (!isRequest(body)) return Response.json({ error: "Choose a goal, duration, and level first." }, { status: 400 });
  const provider = getAIProvider();
  let content: string;
  try {
    content = await provider.chat({
      responseFormat: "json",
      messages: [
        { role: "system", content: "Create a vibration-only TriQuil Rhythm. Return JSON with name, objective, intensity, why, timingUnitMs, pauseMs, loopCount, and tracks. tracks must contain exactly P6, LU9, H7 in that order. Each track needs 1-40 Steps shaped as {amplitude,durationBeats}; amplitude is an integer 0-100 and durationBeats is a positive integer where each beat is 10 ms. timingUnitMs must be 10, pauseMs must be 0-60000, and loopCount must be 1-1000. Use only supplied user context, no sensors, diagnosis, medical claims, or electrical guidance." },
        { role: "user", content: JSON.stringify(body) },
      ],
    });
  } catch {
    return Response.json({ pattern: fallback(body), provider: "fallback" });
  }

  try {
    const pattern = normalizeModelPattern(JSON.parse(content), body);
    return Response.json({ pattern, provider: provider.name });
  } catch {
    return Response.json({ pattern: fallback(body), provider: provider.name });
  }
}
