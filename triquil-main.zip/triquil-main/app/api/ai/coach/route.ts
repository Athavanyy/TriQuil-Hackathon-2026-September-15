import { getAIProvider } from "@/lib/ai/provider";

type CoachRequest = {
  message: string;
  sessionName?: string;
  rhythm?: { name: string; objective: string; duration: number; intensity: number; level: string };
};

function isCoachRequest(value: unknown): value is CoachRequest {
  if (!value || typeof value !== "object") return false;
  const request = value as Partial<CoachRequest>;
  return typeof request.message === "string" && request.message.trim().length > 0;
}

function safeLocalReply(message: string, sessionName?: string, rhythm?: CoachRequest["rhythm"]) {
  if (/heart\s*rate|\bhrv\b|\bgsr\b|sleep\s*stage|stress\s*(reading|measurement|level)/i.test(message)) {
    return "TriQuil does not measure heart rate, HRV, stress, GSR, or sleep stages; it is a vibration-only general-wellness device.";
  }
  if (/do i have|diagnos|anxiety|depression|insomnia|medical condition/i.test(message)) {
    return "TriQuil cannot diagnose anxiety or any medical condition; it provides vibration-only general-wellness Sessions, and a qualified professional can help with health concerns.";
  }
  if (/explain.*generated.*rhythm|explain.*custom.*rhythm/i.test(message) && rhythm) {
    return `${rhythm.name} uses a ${rhythm.level.toLowerCase()} ${rhythm.intensity}% three-point vibration Rhythm for ${rhythm.duration} minutes to ${rhythm.objective.toLowerCase()}`;
  }
  if (/why did you recommend|explain (this|the) (session|recommendation|rhythm)/i.test(message)) {
    return sessionName ? `${sessionName} was recommended from your selected goal, Session history, and explicit feedback.` : "Your recommendation uses only your selected goal, Session history, and explicit feedback.";
  }
  if (/connect|bluetooth|pair/i.test(message)) {
    return "Power on TriQuil, hold its button for 3 seconds, select the demo device in the scan list, and choose Connect.";
  }
  return null;
}

function isUnsafeReply(reply: string) {
  return /(?:your|measured|detected)\s+(?:heart\s*rate|hrv|stress|gsr|sleep\s*stage)|diagnos|\b(?:cure|treats?|prevents?)\s+(?:disease|anxiety|depression|insomnia)|electrical\s*stimulation/i.test(reply);
}

export async function POST(request: Request) {
  let body: unknown;

  try {
    body = await request.json();
  } catch {
    return Response.json({ error: "Request body must be valid JSON." }, { status: 400 });
  }

  if (!isCoachRequest(body)) {
    return Response.json({ error: "message is required." }, { status: 400 });
  }

  const localReply = safeLocalReply(body.message, body.sessionName, body.rhythm);
  if (localReply) return Response.json({ reply: localReply, provider: "safety" });

  try {
    const provider = getAIProvider();
    const content = await provider.chat({
      messages: [
        {
          role: "system",
          content:
            "You are TriQuil Coach, a calm and supportive general-wellness coach. Answer the user's actual question directly in simple language. Usually write 2-5 short sentences and no more than 100 words unless the user explicitly asks for detail. Use short paragraphs; when steps help, use no more than 3-4 short Markdown bullets. Use TriQuil Session context only when relevant. TriQuil is a haptic-only inner-wrist device with three vibration actuators. Never claim access to stress, heart rate, HRV, GSR, sleep-stage, fluid, or clinical data. Never diagnose or treat disease, promise outcomes, invent sensor readings or device capabilities, or provide electrical-stimulation guidance for the separate Neurostim product. When asked for medical advice or unsupported readings, clearly state the limitation and suggest a qualified professional when appropriate.",
        },
        {
          role: "user",
          content: `${body.sessionName ? `Current Session: ${body.sessionName}\n` : ""}${body.rhythm ? `Current generated Rhythm: ${JSON.stringify(body.rhythm)}\n` : ""}${body.message.trim()}`,
        },
      ],
      temperature: 0.4,
    });

    const reply = typeof content === "string" && content.trim().length > 0 && !isUnsafeReply(content)
      ? content.trim()
      : "I can help with general-wellness setup, Session pacing, breathing guidance, or reflection, but I cannot provide medical claims or physiological readings.";

    return Response.json({ reply, provider: provider.name });
  } catch {
    return Response.json({
      reply:
        "I can help with TriQuil setup, Session pacing, or a short reflection. I do not have access to physiological readings or medical information.",
      provider: "fallback",
    });
  }
}