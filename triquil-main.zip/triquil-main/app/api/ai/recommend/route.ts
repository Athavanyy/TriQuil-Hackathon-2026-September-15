import { sessions, type Level, type SessionFeedback } from "@/lib/demo-data";
import { getAIProvider } from "@/lib/ai/provider";

type RecommendationRequest = {
  goal: string;
  timeOfDay?: string;
  availableSessions: string[];
  recentSessions?: string[];
  feedback?: SessionFeedback[];
  duration: number;
  level: Level;
  favorites?: string[];
};

type Recommendation = {
  sessionName: string;
  duration: number;
  intensity: number;
  level: Level;
  reason: string;
  coachingMessage?: string;
};

const approvedNames = new Set(sessions.map((session) => session.name));
const allowedDurations = new Set([5, 10, 15, 20]);
const allowedLevels = new Set<Level>(["Gentle", "Balanced", "Strong"]);

function isShortSentence(value: unknown): value is string {
  if (typeof value !== "string") return false;
  const sentence = value.trim();
  if (sentence.length < 10 || sentence.length > 180 || !/[.!?]$/.test(sentence)) return false;
  return (sentence.match(/[.!?](?:\s|$)/g) || []).length === 1;
}

function isRecommendationRequest(value: unknown): value is RecommendationRequest {
  if (!value || typeof value !== "object") return false;
  const request = value as Partial<RecommendationRequest>;
  return (
    typeof request.goal === "string" && request.goal.trim().length > 0 &&
    Array.isArray(request.availableSessions) && request.availableSessions.length > 0 && request.availableSessions.every((session) => typeof session === "string" && approvedNames.has(session)) &&
    allowedDurations.has(request.duration || 0) && allowedLevels.has(request.level as Level) &&
    (request.recentSessions === undefined || (Array.isArray(request.recentSessions) && request.recentSessions.every((session) => typeof session === "string" && approvedNames.has(session)))) &&
    (request.favorites === undefined || (Array.isArray(request.favorites) && request.favorites.every((session) => typeof session === "string" && approvedNames.has(session)))) &&
    (request.feedback === undefined || (Array.isArray(request.feedback) && request.feedback.every((item) => item && approvedNames.has(item.sessionName) && Number.isInteger(item.rating) && item.rating >= 1 && item.rating <= 5 && (item.comfort === undefined || ["too weak", "comfortable", "too strong"].includes(item.comfort)))))
  );
}

function fallbackRecommendation(request: RecommendationRequest): Recommendation {
  const available = sessions.filter((session) => request.availableSessions.includes(session.name));
  const normalizedGoal = request.goal.toLowerCase();
  const goalPreference = normalizedGoal.includes("sleep") ? "Sleep Support" : normalizedGoal.includes("focus") ? "Focus Flow" : normalizedGoal.includes("relax") ? "Calming Breath" : "Recovery Pulse";
  const score = (sessionName: string) => {
    let value = sessionName === goalPreference ? 8 : 0;
    value += request.favorites?.includes(sessionName) ? 4 : 0;
    value += request.recentSessions?.includes(sessionName) ? 1 : 0;
    for (const item of request.feedback || []) {
      if (item.sessionName !== sessionName) continue;
      value += item.rating <= 2 ? -10 : item.rating - 3;
      if (item.comfort === "comfortable") value += 2;
      if (item.comfort === "too strong" && request.level === "Gentle") value += 1;
      if (item.comfort === "too weak" && request.level === "Strong") value += 1;
    }
    return value;
  };
  const session = [...available].sort((a, b) => score(b.name) - score(a.name))[0] || available[0];
  const matchingFeedback = request.feedback?.find((item) => item.sessionName === session.name);
  const lowFeedback = request.feedback?.find((item) => item.rating <= 2 || item.comfort === "too strong" || item.comfort === "too weak");
  const feedbackReason = matchingFeedback && matchingFeedback.rating >= 4 ? ` and rated ${session.name} highly` : matchingFeedback?.comfort === "comfortable" ? ` and found ${session.name} comfortable` : "";
  const baseIntensity = request.level === "Gentle" ? 20 : request.level === "Strong" ? 50 : 35;
  return {
    sessionName: session.name,
    duration: request.duration,
    intensity: lowFeedback?.comfort === "too strong" ? Math.max(10, baseIntensity - 10) : lowFeedback?.comfort === "too weak" ? Math.min(50, baseIntensity + 10) : baseIntensity,
    level: request.level,
    reason: matchingFeedback && matchingFeedback.rating >= 4
      ? `Recommended because you selected ${request.goal.trim()}${feedbackReason}.`
      : lowFeedback
        ? `Recommended because you selected ${request.goal.trim()} and rated ${lowFeedback.sessionName} ${lowFeedback.rating}/5 as ${lowFeedback.comfort || "less helpful"}.`
        : `Recommended because you selected ${request.goal.trim()}${feedbackReason}.`,
    coachingMessage: "Settle in comfortably and follow the Rhythm at your own pace.",
  };
}

export async function POST(request: Request) {
  let body: unknown;
  try {
    body = await request.json();
  } catch {
    return Response.json({ error: "Request body must be valid JSON." }, { status: 400 });
  }
  if (!isRecommendationRequest(body)) {
    return Response.json({ error: "Choose a valid goal, duration, level, and approved Session list." }, { status: 400 });
  }

  const fallback = fallbackRecommendation(body);
  const prompt = [
    `Selected goal: ${body.goal.trim()}`,
    `Selected duration: ${body.duration} minutes`,
    `Selected level: ${body.level}`,
    body.timeOfDay ? `Time of day: ${body.timeOfDay}` : "",
    `Recent completed Sessions: ${body.recentSessions?.join(", ") || "none provided"}`,
    `Explicit feedback: ${body.feedback?.map((item) => `${item.sessionName} rated ${item.rating}/5${item.comfort ? `, comfort ${item.comfort}` : ""}`).join("; ") || "none provided"}`,
    `Favorites: ${body.favorites?.join(", ") || "none provided"}`,
    `Approved Sessions: ${body.availableSessions.join(", ")}`,
  ].filter(Boolean).join("\n");

  const provider = getAIProvider();
  let content: string;
  try {
    content = await provider.chat({
      responseFormat: "json",
      messages: [
        { role: "system", content: "Recommend only an approved TriQuil Session using only supplied user inputs. Return JSON with exactly sessionName, duration, intensity, level, reason, and optional coachingMessage. The reason must be one short sentence ending in punctuation that names the actual goal, history, rating, comfort, favorite, duration, level, or time input behind the choice. Never invent sensor data, diagnose, or make medical claims." },
        { role: "user", content: prompt },
      ],
    });
  } catch {
    return Response.json({ recommendation: fallback, provider: "fallback" });
  }

  try {
    const recommendation = JSON.parse(content) as Partial<Recommendation>;
    const referencesInput = recommendation.reason?.toLowerCase().includes(body.goal.toLowerCase()) && (
      !body.feedback?.length || body.feedback.some((item) => recommendation.reason?.includes(item.sessionName) || recommendation.reason?.includes(`${item.rating}/5`) || (item.comfort ? recommendation.reason?.toLowerCase().includes(item.comfort) : false))
    );
    if (
      typeof recommendation.sessionName !== "string" || !body.availableSessions.includes(recommendation.sessionName) ||
      recommendation.duration !== body.duration || typeof recommendation.intensity !== "number" || !Number.isInteger(recommendation.intensity) || recommendation.intensity < 1 || recommendation.intensity > 100 ||
      recommendation.level !== body.level || !isShortSentence(recommendation.reason) || !referencesInput ||
      (recommendation.coachingMessage !== undefined && typeof recommendation.coachingMessage !== "string")
    ) throw new Error("Invalid recommendation");
    return Response.json({ recommendation, provider: provider.name });
  } catch {
    return Response.json({ recommendation: fallback, provider: provider.name });
  }
}
