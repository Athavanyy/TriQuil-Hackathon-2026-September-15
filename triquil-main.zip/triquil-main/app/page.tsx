"use client";

import { useEffect, useState } from "react";
import ReactMarkdown from "react-markdown";
import rehypeSanitize from "rehype-sanitize";
import remarkGfm from "remark-gfm";
import {
  CustomTreatmentForm,
  DashboardParityLinks,
  EntryFlow,
  FavoritesScreen,
  MiniSessionPlayer,
  ProfileSubScreen,
  TreatmentDetailsScreen,
  exportHistory,
  type CustomerView,
} from "./customer-parity";
import {
  device,
  durationOptions,
  initialHistory,
  levels,
  sessions,
  validatePattern,
  type CustomPattern,
  type Level,
  type Session,
  type SessionFeedback,
  type SessionHistory,
} from "@/lib/demo-data";

type Tab = "home" | "history" | "custom" | "profile";
type Recommendation = { sessionName: string; duration: number; intensity: number; level: Level; reason: string; coachingMessage?: string };
type PairingState = "Not connected" | "Scanning" | "Choose Device" | "Pairing" | "Connected";
type Recognition = {
  start(): void;
  onresult:
    | ((event: {
        results: { [key: number]: { [key: number]: { transcript: string } } };
      }) => void)
    | null;
  onerror: (() => void) | null;
  onend: (() => void) | null;
};
type SpeechWindow = Window & {
  SpeechRecognition?: new () => Recognition;
  webkitSpeechRecognition?: new () => Recognition;
};

type StartSession = (sessionName: string, resetElapsed?: boolean) => void;

function loadFeedback(): SessionFeedback[] {
  if (typeof window === "undefined") return [];
  try {
    const value = JSON.parse(
      localStorage.getItem("triquil-feedback") || "[]",
    ) as unknown;
    if (!Array.isArray(value)) return [];
    return value.filter((item): item is SessionFeedback => {
      if (!item || typeof item !== "object") return false;
      const feedback = item as Partial<SessionFeedback>;
      return typeof feedback.sessionName === "string" && Number.isInteger(feedback.rating) && (feedback.rating || 0) >= 1 && (feedback.rating || 0) <= 5 && (feedback.comfort === undefined || ["too weak", "comfortable", "too strong"].includes(feedback.comfort));
    });
  } catch {
    return [];
  }
}

function markdownToSpeechText(markdown: string) {
  return markdown
    .replace(/<script\b[^>]*>[\s\S]*?<\/script>/gi, " ")
    .replace(/<style\b[^>]*>[\s\S]*?<\/style>/gi, " ")
    .replace(/<[^>]*>/g, " ")
    .replace(/!\[([^\]]*)\]\([^)]*\)/g, "$1")
    .replace(/\[([^\]]+)\]\([^)]*\)/g, "$1")
    .replace(/[*_~`>#]/g, "")
    .replace(/^\s*[-+]\s+/gm, "")
    .replace(/^\s*\d+[.)]\s+/gm, "")
    .replace(/\s+/g, " ")
    .trim();
}

function CoachMarkdown({ children }: { children: string }) {
  return (
    <ReactMarkdown
      remarkPlugins={[remarkGfm]}
      rehypePlugins={[rehypeSanitize]}
      skipHtml
      disallowedElements={["a", "img"]}
      unwrapDisallowed
    >
      {children}
    </ReactMarkdown>
  );
}

function MobileHeader({ onCoach }: { onCoach: () => void }) {
  return (
    <header className="mobile-header">
      <div className="mobile-brand">
        <span className="brand-mark" aria-hidden="true">BC</span>
        <span>
          <strong>TriQuil</strong>
          <small>wellness companion</small>
        </span>
      </div>
      <button className="coach-button" onClick={onCoach} aria-label="Open AI Coach">
        <span aria-hidden="true">✦</span>
        <span className="coach-button-label">AI Coach</span>
      </button>
    </header>
  );
}

function ScreenIntro({ eyebrow, title }: { eyebrow: string; title: string }) {
  return (
    <div className="screen-intro">
      <p className="eyebrow">{eyebrow}</p>
      <h1>{title}</h1>
    </div>
  );
}

function DeviceCard({
  pairing,
  onPair,
}: {
  pairing: PairingState;
  onPair: () => void;
}) {
  const connected = pairing === "Connected";
  return (
    <section className="device-card" aria-label="Device status">
      <div className="device-card-top">
        <span className={`device-icon ${connected ? "connected" : ""}`} aria-hidden="true">⌁</span>
        <span className="device-copy">
          <small>DEVICE</small>
          <strong>TriQuil</strong>
          <span><i className={`status-dot ${connected ? "" : "status-warm"}`} />{pairing}</span>
        </span>
        <span className="battery">▰ {device.battery}%</span>
      </div>
      <div className="device-meta">
        <span>{connected ? device.serialNumber : "Bluetooth demo"}</span>
        <span>{connected ? `Firmware ${device.firmware}` : "No hardware connected"}</span>
      </div>
      <button className="secondary-button full-button" onClick={onPair}>
        {connected ? "Reconnect Device" : "Connect Device"}
      </button>
      <p className="demo-note">Demo Mode · pairing and playback are simulated.</p>
    </section>
  );
}

function RecommendationCard({
  recommendation,
  selected,
  pattern,
  duration,
  level,
  shownDuration,
  shownIntensity,
  goal,
  loading,
  error,
  onDuration,
  onLevel,
  onGoal,
  onRefresh,
  onStart,
}: {
  recommendation: Recommendation;
  selected: Session;
  pattern: CustomPattern | null;
  duration: number;
  level: Level;
  shownDuration: number;
  shownIntensity: number;
  goal: string;
  loading: boolean;
  error: string;
  onDuration: (duration: number) => void;
  onLevel: (level: Level) => void;
  onGoal: (goal: string) => void;
  onRefresh: () => void;
  onStart: () => void;
}) {
  return (
    <section className="recommendation-card">
      <div className="card-label-row">
        <span className="section-label">AI RECOMMENDED SESSION</span>
        <span className="ai-pill">AI</span>
      </div>
      <p className="recommendation-reason">{recommendation.reason}</p>
      {error && <p className="friendly-error">{error}</p>}
      <div className="recommendation-session">
        <div className="session-orbit" aria-hidden="true"><span>✦</span></div>
        <div className="recommendation-copy">
          <small>{pattern ? "CUSTOM RHYTHM" : "RECOMMENDED RHYTHM"}</small>
          <h2>{pattern?.name || recommendation.sessionName}</h2>
          <p>{selected.objective}</p>
          <div className="session-facts">
            <span>{shownDuration} min</span>
            <span>{shownIntensity}%</span>
            <span>{level}</span>
          </div>
        </div>
      </div>
      <button className="primary-button full-button" onClick={onStart}>Start Session <span>→</span></button>
      <div className="control-row">
        <label>
          Session time
          <select value={duration} onChange={(event) => onDuration(Number(event.target.value))}>
            {durationOptions.map((item) => <option key={item} value={item}>{item} min</option>)}
          </select>
        </label>
        <label>
          Level
          <select value={level} onChange={(event) => onLevel(event.target.value as Level)}>
            {(Object.keys(levels) as Level[]).map((item) => <option key={item}>{item}</option>)}
          </select>
        </label>
      </div>
      <div className="goal-row">
        <label htmlFor="goal">Goal</label>
        <select id="goal" value={goal} onChange={(event) => onGoal(event.target.value)}>
          <option value="focus">Focus</option>
          <option value="relaxation">Relax</option>
          <option value="sleep preparation">Better Sleep</option>
          <option value="recovery">Recovery</option>
        </select>
        <button className="text-button" onClick={onRefresh} disabled={loading}>
          {loading ? <><span className="spinner" /> Thinking...</> : "Refresh →"}
        </button>
      </div>
    </section>
  );
}

function RhythmCard({
  pattern,
  selected,
  tracks,
  onPreview,
}: {
  pattern: CustomPattern | null;
  selected: Session;
  tracks: CustomPattern["tracks"];
  onPreview: () => void;
}) {
  return (
    <section className="rhythm-card">
      <div className="card-label-row">
        <span className="section-label">DEVICE RHYTHM</span>
        <span className="ready-label"><i className="status-dot" />Ready</span>
      </div>
      <h2>{pattern ? "Custom pattern" : "Three-point rhythm"}</h2>
      <div className="track-visual" aria-label="Pattern visualization">
        {tracks.map((track) => (
          <div className="track-line" key={track.actuator}>
            <span>{track.actuator}</span>
            <div>
              {track.steps.concat(track.steps, track.steps).map((step, index) => (
                <i key={index} style={{ height: `${Math.max(step.amplitude, 8)}%` }} />
              ))}
            </div>
          </div>
        ))}
      </div>
      <div className="rhythm-meta">
        <span><small>Pattern</small><strong>{pattern?.name || selected.pattern}</strong></span>
        <span><small>Points</small><strong>P6 · LU9 · H7</strong></span>
      </div>
      <button className="light-button full-button" onClick={onPreview}>Preview Rhythm <span>↗</span></button>
    </section>
  );
}

function SectionHeading({ label, title, meta }: { label: string; title: string; meta?: string }) {
  return (
    <div className="section-heading">
      <div>
        <p className="section-label">{label}</p>
        <h2>{title}</h2>
      </div>
      {meta && <span className="section-meta">{meta}</span>}
    </div>
  );
}

function TreatmentList({
  recommendation,
  onChoose,
  onDetails,
}: {
  recommendation: Recommendation;
  onChoose: (session: Session) => void;
  onDetails: (session: Session) => void;
}) {
  return (
    <section className="treatments-section">
      <SectionHeading label="TREATMENT MODES" title="Choose a Session" meta={`${sessions.length} approved`} />
      <div className="session-list">
        {sessions.map((session) => (
          <button
            className={`session-row ${session.name === recommendation.sessionName ? "selected" : ""}`}
            key={session.name}
            onClick={() => { onChoose(session); onDetails(session); }}
          >
            <span className="session-icon" aria-hidden="true">◉</span>
            <span className="session-copy">
              <strong>{session.name}</strong>
              <small>{session.objective}</small>
            </span>
            <span className="session-duration">{session.duration} min</span>
            <span className="session-action" aria-hidden="true">→</span>
          </button>
        ))}
      </div>
    </section>
  );
}

function RecentSessions({
  history,
  preview,
  onRestart,
}: {
  history: SessionHistory[];
  preview: boolean;
  onRestart: StartSession;
}) {
  const shownHistory = preview ? history.slice(0, 3) : history;
  return (
    <section className="recent-section">
      <SectionHeading
        label={preview ? "YOUR PRACTICE" : "SESSION HISTORY"}
        title="Recent Sessions"
        meta={preview ? "Latest 3" : `${shownHistory.length} sessions`}
      />
      <div className="history-list">
        {shownHistory.map((item) => {
          const session = sessions.find((candidate) => candidate.name === item.sessionName) || sessions[0];
          return (
            <article className="history-row" key={`${item.sessionName}-${item.completedAt}`}>
              <span className="history-check" aria-hidden="true">✓</span>
              <span className="history-copy">
                <strong>{item.sessionName}</strong>
                <small>{item.completedAt} · {session.duration} min</small>
              </span>
              <span className="rating" aria-label={`${item.rating || 0} out of 5 stars`}>
                {item.rating ? "★".repeat(item.rating) : "—"}
              </span>
              <button className="restart-button" onClick={() => onRestart(session.name, true)} aria-label={`Restart ${item.sessionName}`}>↻</button>
            </article>
          );
        })}
      </div>
    </section>
  );
}

function TriangleCard() {
  return (
    <section className="triangle-card">
      <span className="triangle-icon" aria-hidden="true">△</span>
      <div>
        <h2>TriQuil Triangle</h2>
        <p>Three inner-wrist points. One deliberate Session.</p>
      </div>
    </section>
  );
}

function HomeScreen({
  pairing,
  recommendation,
  selected,
  pattern,
  duration,
  level,
  shownDuration,
  shownIntensity,
  goal,
  loading,
  error,
  history,
  tracks,
  onPair,
  onDuration,
  onLevel,
  onGoal,
  onRefresh,
  onStart,
  onPreview,
  onChoose,
  onDetails,
  onFavorites,
  onCustom,
}: {
  pairing: PairingState;
  recommendation: Recommendation;
  selected: Session;
  pattern: CustomPattern | null;
  duration: number;
  level: Level;
  shownDuration: number;
  shownIntensity: number;
  goal: string;
  loading: boolean;
  error: string;
  history: SessionHistory[];
  tracks: CustomPattern["tracks"];
  onPair: () => void;
  onDuration: (duration: number) => void;
  onLevel: (level: Level) => void;
  onGoal: (goal: string) => void;
  onRefresh: () => void;
  onStart: StartSession;
  onPreview: () => void;
  onChoose: (session: Session) => void;
  onDetails: (session: Session) => void;
  onFavorites: () => void;
  onCustom: () => void;
}) {
  return (
    <div className="screen home-screen" data-screen="HomeScreen">
      <ScreenIntro eyebrow="Tuesday, September 15" title="Good morning, Alex" />
      <DeviceCard pairing={pairing} onPair={onPair} />
      <RecommendationCard
        recommendation={recommendation}
        selected={selected}
        pattern={pattern}
        duration={duration}
        level={level}
        shownDuration={shownDuration}
        shownIntensity={shownIntensity}
        goal={goal}
        loading={loading}
        error={error}
        onDuration={onDuration}
        onLevel={onLevel}
        onGoal={onGoal}
        onRefresh={onRefresh}
        onStart={() => onStart(selected.name, true)}
      />
      <RhythmCard pattern={pattern} selected={selected} tracks={tracks} onPreview={onPreview} />
      <DashboardParityLinks onFavorites={onFavorites} onCustom={onCustom} />
      <TreatmentList recommendation={recommendation} onChoose={onChoose} onDetails={onDetails} />
      <RecentSessions history={history} preview onRestart={onStart} />
      <TriangleCard />
    </div>
  );
}

function HistoryScreen({ history, onRestart }: { history: SessionHistory[]; onRestart: StartSession }) {
  return (
    <div className="screen history-screen" data-screen="HistoryScreen">
      <ScreenIntro eyebrow="YOUR PRACTICE" title="History" />
      <button className="secondary-button full-button" onClick={() => exportHistory(history)}>Export History</button>
      <RecentSessions history={history} preview={false} onRestart={onRestart} />
    </div>
  );
}

function CustomScreen({
  pattern,
  patternRequest,
  patternLoading,
  patternError,
  onRequest,
  onGenerate,
  onAdd,
}: {
  pattern: CustomPattern | null;
  patternRequest: string;
  patternLoading: boolean;
  patternError: string;
  onRequest: (request: string) => void;
  onGenerate: (request?: string) => void;
  onAdd: () => void;
}) {
  const quickGenerate = (request: string) => {
    onRequest(request);
    onGenerate(request);
  };
  return (
    <div className="screen custom-screen" data-screen="CustomScreen">
      <ScreenIntro eyebrow="YOUR LIBRARY" title="My Custom Treatments" />
      <button className="secondary-button add-treatment-button" onClick={onAdd}>+ Add Custom Treatment</button>
      <section className="custom-card">
        <span className="custom-icon" aria-hidden="true">✦</span>
        <p className="section-label">GENERATE AI TREATMENT</p>
        <h2>AI Pattern Generator</h2>
        <p>Describe the moment. TriQuil shapes a vibration-only rhythm within its three-point structure.</p>
        <div className="quick-prompts">
          <button onClick={() => quickGenerate("calm rhythm right now")}>Relax me now</button>
          <button onClick={() => quickGenerate("focus pattern for studying")}>Focus pattern</button>
          <button onClick={() => quickGenerate("sleep-prep pattern")}>Sleep pattern</button>
        </div>
        <label className="pattern-field">
          What do you need?
          <textarea
            value={patternRequest}
            onChange={(event) => onRequest(event.target.value)}
            placeholder="e.g. I need a calm rhythm right now"
            rows={3}
          />
        </label>
        <button className="primary-button full-button" onClick={() => onGenerate()} disabled={patternLoading}>
          {patternLoading ? <><span className="spinner light" /> Creating...</> : "Generate Best Pattern for Me Right Now"}
        </button>
        {patternError && <p className="friendly-error">{patternError}</p>}
      </section>
      <section className="generated-card">
        <p className="section-label">GENERATED TREATMENT PREVIEW</p>
        {pattern ? (
          <>
            <h2>{pattern.name}</h2>
            <div className="generated-facts">
              <span>{pattern.goal}</span><span>{pattern.duration} min</span><span>{pattern.intensity}%</span><span>{pattern.level}</span>
            </div>
            <p><strong>{pattern.objective}</strong></p>
            <p>{pattern.why}</p>
            <div className="generated-tracks">
              {pattern.tracks.map((track) => <span key={track.actuator}><strong>{track.actuator}</strong> · {track.steps.length} Steps · {track.steps.map((step) => `${step.amplitude}%/${step.durationBeats * pattern.timingUnitMs}ms`).join(" · ")}</span>)}
            </div>
            <small>Validated: A/P6 · B/LU9 · C/H7 · {pattern.timingUnitMs} ms timing · {pattern.pauseMs} ms pause · {pattern.loopCount} loops</small>
          </>
        ) : (
          <div className="empty-preview">
            <span aria-hidden="true">◇</span>
            <h2>Generated Treatment preview</h2>
            <p>Your next AI treatment will appear here.</p>
          </div>
        )}
      </section>
    </div>
  );
}

const profileGroups = [
  { icon: "⌁", title: "Device", detail: `${device.serialNumber} · Connected` },
  { icon: "♙", title: "Members", detail: "Alex Rivera · Personal plan" },
  { icon: "◇", title: "Subscription", detail: "TriQuil Personal" },
  { icon: "◌", title: "Notification Settings", detail: "Session reminders on" },
  { icon: "↟", title: "Firmware", detail: `Version ${device.firmware}` },
  { icon: "?", title: "FAQ", detail: "Answers to common questions" },
  { icon: "♡", title: "Help & Support", detail: "Get help with TriQuil" },
  { icon: "▣", title: "Privacy Policy", detail: "How your information is handled" },
  { icon: "≡", title: "Terms of Service", detail: "TriQuil terms" },
  { icon: "↗", title: "Learn More", detail: "Explore TriQuil wellness" },
];

function ProfileScreen({ onOpen }: { onOpen: (view: CustomerView) => void }) {
  return (
    <div className="screen profile-screen" data-screen="ProfileScreen">
      <ScreenIntro eyebrow="ACCOUNT" title="Profile" />
      <button className="profile-hero profile-hero-button" onClick={() => onOpen("user-info")}>
        <div className="profile-avatar">AR</div>
        <div><h2>Alex Rivera</h2><p>Personal plan · wellness companion</p></div>
        <span aria-hidden="true">›</span>
      </button>
      <div className="profile-list">
        {profileGroups.map((item) => (
          <button className="profile-row" key={item.title} onClick={() => onOpen(({ "Device": "device", "Members": "members", "Subscription": "subscription", "Notification Settings": "notifications", "Firmware": "firmware", "FAQ": "faq", "Help & Support": "support", "Privacy Policy": "privacy", "Terms of Service": "terms", "Learn More": "learn-more" } as Record<string, CustomerView>)[item.title])}>
            <span className="profile-row-icon" aria-hidden="true">{item.icon}</span>
            <span><strong>{item.title}</strong><small>{item.detail}</small></span>
            <span aria-hidden="true">›</span>
          </button>
        ))}
      </div>
    </div>
  );
}

function BottomNavigation({ activeTab, onTab }: { activeTab: Tab; onTab: (tab: Tab) => void }) {
  const items: { tab: Tab; icon: string; label: string }[] = [
    { tab: "home", icon: "⌂", label: "Home" },
    { tab: "history", icon: "◷", label: "History" },
    { tab: "custom", icon: "✦", label: "Custom" },
    { tab: "profile", icon: "♙", label: "Profile" },
  ];
  return (
    <nav className="bottom-nav" aria-label="Main navigation">
      {items.map((item) => (
        <button
          key={item.tab}
          className={activeTab === item.tab ? "active" : ""}
          onClick={() => onTab(item.tab)}
          aria-current={activeTab === item.tab ? "page" : undefined}
        >
          <span aria-hidden="true">{item.icon}</span>{item.label}
        </button>
      ))}
    </nav>
  );
}

function PairingModal({ pairing, onClose, onScan, onChoose, onConnect }: { pairing: PairingState; onClose: () => void; onScan: () => void; onChoose: () => void; onConnect: () => void }) {
  return (
    <div className="phone-overlay pairing-backdrop" role="dialog" aria-modal="true" aria-label="Pair TriQuil device">
      <section className="pairing-modal">
        <button className="close-button" onClick={onClose} aria-label="Close pairing">×</button>
        <p className="section-label">TRIQUIL DEVICE</p>
        <h2>{pairing === "Connected" ? "Connection Successful" : pairing === "Pairing" ? "Connecting..." : pairing === "Choose Device" ? "Choose Device" : pairing === "Scanning" ? "Scan for Devices" : "Pair your TriQuil"}</h2>
        <div className="pairing-orbit"><span>{pairing === "Connected" ? "✓" : "⌁"}</span></div>
        <p>{pairing === "Connected" ? "Your TriQuil demo device is ready for Sessions." : "Power on the device and hold its button for 3 seconds."}</p>
        {pairing === "Not connected" && <button className="primary-button full-button" onClick={onScan}>Scan for Devices</button>}
        {pairing === "Scanning" && <button className="secondary-button full-button" onClick={onChoose}>Show Demo Device</button>}
        {pairing === "Choose Device" && <button className="device-choice" onClick={onConnect}><span>TriQuil Demo</span><small>{device.serialNumber} · Select to connect</small></button>}
        <div className="pairing-steps">
          <span className={pairing !== "Not connected" ? "done" : ""}>1</span>
          <span className={pairing === "Choose Device" || pairing === "Pairing" || pairing === "Connected" ? "done" : ""}>2</span>
          <span className={pairing === "Connected" ? "done" : ""}>3</span>
        </div>
        <small>Demo pairing only. No Bluetooth hardware is connected.</small>
        {pairing === "Connected" && <button className="primary-button full-button" onClick={onClose}>Continue</button>}
      </section>
    </div>
  );
}

function SessionModal({
  activeSession,
  feedbackSession,
  paused,
  selected,
  pattern,
  level,
  shownDuration,
  shownIntensity,
  elapsed,
  comfort,
  onComfort,
  onClose,
  onPause,
  onFinish,
  onFeedback,
  tracks,
}: {
  activeSession: string | null;
  feedbackSession: string | null;
  paused: boolean;
  selected: Session;
  pattern: CustomPattern | null;
  level: Level;
  shownDuration: number;
  shownIntensity: number;
  elapsed: number;
  comfort: string;
  onComfort: (comfort: string) => void;
  onClose: () => void;
  onPause: () => void;
  onFinish: () => void;
  onFeedback: (rating: number) => void;
  tracks: CustomPattern["tracks"];
}) {
  const remaining = Math.max(shownDuration * 60 - elapsed, 0);
  const time = `${Math.floor(remaining / 60).toString().padStart(2, "0")}:${(remaining % 60).toString().padStart(2, "0")}`;
  return (
    <div className="phone-overlay session-backdrop" role="dialog" aria-modal="true" aria-label="Session player">
      <section className="session-modal">
        <button className="close-button" onClick={onClose} aria-label="Close session">×</button>
        <p className="eyebrow">{feedbackSession ? "SESSION COMPLETE" : paused ? "SESSION PAUSED" : "SIMULATED SESSION"}</p>
        <div className="modal-orbit" aria-hidden="true"><span>◉</span></div>
        <h2>{pattern?.name || selected.name}</h2>
        <p>{pattern?.why || selected.pattern}</p>
        <div className="session-settings"><span>{shownDuration} min</span><span>{shownIntensity}% · {level}</span></div>
        <div className="player-tracks" aria-label="Active P6 LU9 H7 Rhythm">
          {tracks.map((track) => <span key={track.actuator}><strong>{track.actuator}</strong><i style={{ opacity: Math.max(track.steps[elapsed % track.steps.length].amplitude / 100, 0.2) }} /></span>)}
        </div>
        <div className="timer">{time}</div>
        <div className="session-progress"><span style={{ width: `${Math.min((elapsed / (shownDuration * 60)) * 100, 100)}%` }} /></div>
        <p className="simulation-note">Timing preview only. No hardware control is connected.</p>
        {activeSession && !feedbackSession && (
          <div className="modal-actions">
            <button className="secondary-button" onClick={onPause}>{paused ? "Resume" : "Pause"}</button>
            <button className="primary-button" onClick={onFinish}>Finish Session</button>
          </div>
        )}
        {feedbackSession && <div className="feedback">
          <span>How did this Session feel?</span>
          <label>Comfort
            <select value={comfort} onChange={(event) => onComfort(event.target.value)}>
              <option value="comfortable">Comfortable</option>
              <option value="too weak">Too weak</option>
              <option value="too strong">Too strong</option>
            </select>
          </label>
          <div>{[[1, "Not helpful"], [2, "Slightly helpful"], [3, "Okay"], [4, "Helpful"], [5, "Very helpful"]].map(([rating, label]) => <button key={rating} onClick={() => onFeedback(Number(rating))} aria-label={`${rating} - ${label}`}>★</button>)}</div>
        </div>}
      </section>
    </div>
  );
}

function CoachDrawer({
  messages,
  input,
  loading,
  error,
  speaking,
  readAloud,
  pattern,
  onClose,
  onInput,
  onSend,
  onGenerate,
  onVoice,
  onReadAloud,
  onExplain,
}: {
  messages: string[];
  input: string;
  loading: boolean;
  error: string;
  speaking: boolean;
  readAloud: boolean;
  pattern: CustomPattern | null;
  onClose: () => void;
  onInput: (input: string) => void;
  onSend: (text?: string) => void;
  onGenerate: (request: string) => void;
  onVoice: () => void;
  onReadAloud: () => void;
  onExplain: () => void;
}) {
  return (
    <aside className="phone-overlay coach-drawer" role="dialog" aria-modal="true" aria-label="AI Coach">
      <div className="drawer-header">
        <div><p className="section-label">TRIQUIL COACH</p><h2>A quieter next step</h2></div>
        <button className="close-button" onClick={onClose} aria-label="Close AI Coach">×</button>
      </div>
      <div className="coach-quick-actions">
        <button onClick={() => onSend("Relax me now")}>Relax me now</button>
        <button onClick={() => onSend("Help me focus")}>Help me focus</button>
        <button onClick={() => onSend("Prepare for sleep")}>Prepare for sleep</button>
        <button onClick={onExplain}>Explain this Session</button>
        <button onClick={() => onGenerate("generate a pattern for my current goal")}>Generate a pattern</button>
        <button onClick={() => onSend("How should I pace this Session?")}>How should I pace this Session?</button>
      </div>
      <div className="coach-messages">
        {messages.map((message, index) => (
          <div className={message.startsWith("You:") ? "user-message" : "coach-message"} key={`${message}-${index}`}>
            <CoachMarkdown>{message}</CoachMarkdown>
          </div>
        ))}
        {loading && <p className="coach-message thinking"><span className="spinner" /> Thinking...</p>}
        {error && <p className="coach-error">{error}</p>}
      </div>
      <div className="coach-input">
        <input
          value={input}
          onChange={(event) => onInput(event.target.value)}
          onKeyDown={(event) => { if (event.key === "Enter") onSend(); }}
          placeholder="Ask about setup or pacing..."
        />
        <button className="voice-button" onClick={onVoice} aria-label="Press to speak">{speaking ? "◼" : "♪"}</button>
        <button onClick={() => onSend()} disabled={loading} aria-label="Send message">→</button>
      </div>
      <div className="coach-footer">
        <button onClick={onReadAloud}>{readAloud ? "◉ Read aloud on" : "○ Read aloud"}</button>
        <span>Browser voice. General wellness guidance only.</span>
      </div>
      <span className="visually-hidden">{pattern ? `${pattern.name} is selected` : "No custom pattern selected"}</span>
    </aside>
  );
}

export default function Home() {
  const [onboarded, setOnboarded] = useState(false);
  const [activeTab, setActiveTab] = useState<Tab>("home");
  const [customerView, setCustomerView] = useState<CustomerView>("home");
  const [detailSession, setDetailSession] = useState<Session>(sessions[0]);
  const [favorites, setFavorites] = useState<string[]>(["Calming Breath", "Focus Flow"]);
  const [goal, setGoal] = useState("focus");
  const [recommendation, setRecommendation] = useState<Recommendation>({ sessionName: "Focus Flow", duration: 10, intensity: 35, level: "Balanced", reason: "Recommended because you selected Focus and recently completed similar Sessions." });
  const [history, setHistory] = useState<SessionHistory[]>(initialHistory);
  const [feedback, setFeedback] = useState<SessionFeedback[]>(loadFeedback);
  const [duration, setDuration] = useState(10);
  const [level, setLevel] = useState<Level>("Balanced");
  const [activeSession, setActiveSession] = useState<string | null>(null);
  const [feedbackSession, setFeedbackSession] = useState<string | null>(null);
  const [comfort, setComfort] = useState("comfortable");
  const [paused, setPaused] = useState(false);
  const [elapsed, setElapsed] = useState(0);
  const [pairing, setPairing] = useState<PairingState>("Not connected");
  const [pairingOpen, setPairingOpen] = useState(false);
  const [pattern, setPattern] = useState<CustomPattern | null>(null);
  const [patternRequest, setPatternRequest] = useState("");
  const [patternLoading, setPatternLoading] = useState(false);
  const [patternError, setPatternError] = useState("");
  const [coachOpen, setCoachOpen] = useState(false);
  const [coachInput, setCoachInput] = useState("");
  const [coachMessages, setCoachMessages] = useState(["I can help with setup, Session pacing, or a short reflection."]);
  const [coachLoading, setCoachLoading] = useState(false);
  const [coachError, setCoachError] = useState("");
  const [speaking, setSpeaking] = useState(false);
  const [readAloud, setReadAloud] = useState(false);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");

  useEffect(() => {
    const timer = window.setTimeout(() => setOnboarded(localStorage.getItem("triquil-onboarded") === "true"), 0);
    return () => window.clearTimeout(timer);
  }, []);

  const selected = sessions.find((item) => item.name === (activeSession || feedbackSession || recommendation.sessionName)) || sessions[0];
  const shownDuration = pattern?.duration || duration;
  const shownIntensity = pattern?.intensity || recommendation.intensity || levels[level];
  const tracks: CustomPattern["tracks"] = pattern?.tracks || [
    { actuator: "P6", steps: [{ amplitude: shownIntensity, durationBeats: 100 }, { amplitude: shownIntensity - 5, durationBeats: 100 }] },
    { actuator: "LU9", steps: [{ amplitude: shownIntensity - 8, durationBeats: 100 }, { amplitude: shownIntensity, durationBeats: 100 }] },
    { actuator: "H7", steps: [{ amplitude: shownIntensity - 5, durationBeats: 100 }, { amplitude: shownIntensity - 10, durationBeats: 100 }] },
  ];

  useEffect(() => {
    if (!activeSession || paused) return;
    const timer = window.setInterval(() => setElapsed((value) => Math.min(value + 1, shownDuration * 60)), 1000);
    return () => window.clearInterval(timer);
  }, [activeSession, paused, shownDuration]);

  async function refreshRecommendation(nextFeedback = feedback) {
    setLoading(true);
    setError("");
    try {
      const response = await fetch("/api/ai/recommend", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          goal,
          timeOfDay: "morning",
          availableSessions: sessions.map((item) => item.name),
          recentSessions: history.map((item) => item.sessionName),
          feedback: nextFeedback,
          duration,
          level,
          favorites: [],
        }),
      });
      const data = await response.json();
      if (!response.ok || !data.recommendation) throw new Error("recommendation");
      setRecommendation(data.recommendation);
    } catch {
      setError("We couldn’t refresh that recommendation. Your current suggestion is still ready.");
    } finally {
      setLoading(false);
    }
  }

  async function generatePattern(request = patternRequest) {
    setPatternLoading(true);
    setPatternError("");
    try {
      const response = await fetch("/api/ai/pattern", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          goal,
          timeOfDay: "morning",
          duration,
          level,
          request,
          recentSessions: history.map((item) => item.sessionName),
          feedback,
        }),
      });
      const data = await response.json();
      if (!response.ok) throw new Error("pattern");
      setPattern(validatePattern(data.pattern));
    } catch {
      setPatternError("We couldn’t create that pattern just now. Try again in a moment.");
    } finally {
      setPatternLoading(false);
    }
  }

  function startSession(sessionName: string, resetElapsed = false) {
    setActiveSession(sessionName);
    setFeedbackSession(null);
    setPaused(false);
    if (resetElapsed) setElapsed(0);
  }

  function submitFeedback(rating: number) {
    const next = [
      ...feedback.filter((item) => item.sessionName !== selected.name),
      { sessionName: selected.name, rating, comfort },
    ];
    setFeedback(next);
    try { localStorage.setItem("triquil-feedback", JSON.stringify(next)); } catch { /* The in-memory prototype remains usable. */ }
    setHistory((current) => [
      { sessionName: selected.name, completedAt: "Just now", rating },
      ...current.filter((item) => item.sessionName !== selected.name),
    ]);
    setFeedbackSession(null);
    void refreshRecommendation(next);
  }

  async function sendCoach(text = coachInput) {
    if (!text.trim() || coachLoading) return;
    const message = text.trim();
    setCoachInput("");
    setCoachError("");
    setCoachMessages((current) => [...current, `You: ${message}`]);
    setCoachLoading(true);
    try {
      const response = await fetch("/api/ai/coach", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          message,
          sessionName: selected.name,
          rhythm: pattern ? { name: pattern.name, objective: pattern.objective, duration: pattern.duration, intensity: pattern.intensity, level: pattern.level } : undefined,
        }),
      });
      const data = await response.json();
      if (!response.ok || typeof data.reply !== "string") throw new Error("coach");
      setCoachMessages((current) => [...current, data.reply]);
      if (readAloud && "speechSynthesis" in window) window.speechSynthesis.speak(new SpeechSynthesisUtterance(markdownToSpeechText(data.reply)));
    } catch {
      setCoachError("The Coach is taking a quiet pause. Please try again.");
    } finally {
      setCoachLoading(false);
    }
  }

  function startVoice() {
    const speech = window as SpeechWindow;
    const Recognition = speech.SpeechRecognition || speech.webkitSpeechRecognition;
    if (!Recognition) {
      setCoachError("Voice input is not available in this browser. You can type instead.");
      return;
    }
    const recognition = new Recognition();
    setSpeaking(true);
    recognition.onresult = (event) => {
      const text = event.results[0][0].transcript;
      setCoachInput(text);
      void sendCoach(text);
    };
    recognition.onerror = () => setCoachError("Voice input paused. You can type instead.");
    recognition.onend = () => setSpeaking(false);
    recognition.start();
  }

  function pairDevice() {
    setPairingOpen(true);
    setPairing("Not connected");
  }

  function connectDevice() {
    setPairing("Pairing");
    window.setTimeout(() => setPairing("Connected"), 800);
  }

  function chooseSession(session: Session) {
    setPattern(null);
    setDuration(durationOptions.includes(session.duration as (typeof durationOptions)[number]) ? session.duration : 10);
    setRecommendation({ sessionName: session.name, duration: session.duration, intensity: session.intensity, level, reason: `Selected because you chose ${session.name} from the approved Session library.` });
  }

  function navigateTab(tab: Tab) {
    setActiveTab(tab);
    setCustomerView(tab);
  }

  function openTreatment(session: Session) {
    setDetailSession(session);
    setCustomerView("treatment");
  }

  function toggleFavorite(name: string) {
    setFavorites((current) => current.includes(name) ? current.filter((item) => item !== name) : [...current, name]);
  }

  if (!onboarded) {
    return <div className="viewport-shell"><div className="phone-app entry-phone"><EntryFlow onComplete={() => setOnboarded(true)} /></div></div>;
  }

  return (
    <div className="viewport-shell">
      <div className="phone-app">
        <MobileHeader onCoach={() => setCoachOpen(true)} />
        <main className="mobile-content">
          {customerView === "home" && (
            <HomeScreen
              pairing={pairing}
              recommendation={recommendation}
              selected={selected}
              pattern={pattern}
              duration={duration}
              level={level}
              shownDuration={shownDuration}
              shownIntensity={shownIntensity}
              goal={goal}
              loading={loading}
              error={error}
              history={history}
              tracks={tracks}
              onPair={pairDevice}
              onDuration={setDuration}
              onLevel={setLevel}
              onGoal={setGoal}
              onRefresh={() => void refreshRecommendation()}
              onStart={startSession}
              onPreview={() => startSession(selected.name)}
              onChoose={chooseSession}
              onDetails={openTreatment}
              onFavorites={() => setCustomerView("favorites")}
              onCustom={() => navigateTab("custom")}
            />
          )}
          {customerView === "history" && <HistoryScreen history={history} onRestart={startSession} />}
          {customerView === "custom" && (
            <CustomScreen
              pattern={pattern}
              patternRequest={patternRequest}
              patternLoading={patternLoading}
              patternError={patternError}
              onRequest={setPatternRequest}
              onGenerate={(request) => void generatePattern(request)}
              onAdd={() => setCustomerView("custom-form")}
            />
          )}
          {customerView === "profile" && <ProfileScreen onOpen={setCustomerView} />}
          {customerView === "treatment" && <TreatmentDetailsScreen session={detailSession} connected={pairing === "Connected"} favorite={favorites.includes(detailSession.name)} onBack={() => setCustomerView(activeTab)} onFavorite={() => toggleFavorite(detailSession.name)} onStart={() => startSession(detailSession.name, true)} />}
          {customerView === "favorites" && <FavoritesScreen favorites={favorites} onBack={() => setCustomerView("home")} onToggle={toggleFavorite} onPlay={(name) => startSession(name, true)} />}
          {customerView === "custom-form" && <CustomTreatmentForm onBack={() => setCustomerView("custom")} onCreate={(created) => { setPattern(validatePattern(created)); setCustomerView("custom"); }} />}
          {(["user-info", "device", "members", "subscription", "notifications", "firmware", "faq", "support", "privacy", "terms", "learn-more"] as CustomerView[]).includes(customerView) && <ProfileSubScreen view={customerView} onBack={() => setCustomerView("profile")} onReplay={() => { localStorage.removeItem("triquil-onboarded"); setOnboarded(false); }} />}
        </main>
        <BottomNavigation activeTab={activeTab} onTab={navigateTab} />

        {activeSession && !feedbackSession && <MiniSessionPlayer name={pattern?.name || selected.name} paused={paused} onOpen={() => undefined} onPause={() => setPaused((value) => !value)} onStop={() => { setActiveSession(null); setPaused(false); }} />}

        {pairingOpen && <PairingModal pairing={pairing} onClose={() => setPairingOpen(false)} onScan={() => setPairing("Scanning")} onChoose={() => setPairing("Choose Device")} onConnect={connectDevice} />}
        {(activeSession || feedbackSession) && (
          <SessionModal
            activeSession={activeSession}
            feedbackSession={feedbackSession}
            paused={paused}
            selected={selected}
            pattern={pattern}
            level={level}
            shownDuration={shownDuration}
            shownIntensity={shownIntensity}
            elapsed={elapsed}
            comfort={comfort}
            onComfort={setComfort}
            onClose={() => { setActiveSession(null); setFeedbackSession(null); }}
            onPause={() => setPaused((value) => !value)}
            onFinish={() => { setActiveSession(null); setFeedbackSession(selected.name); }}
            onFeedback={submitFeedback}
            tracks={tracks}
          />
        )}
        {coachOpen && (
          <CoachDrawer
            messages={coachMessages}
            input={coachInput}
            loading={coachLoading}
            error={coachError}
            speaking={speaking}
            readAloud={readAloud}
            pattern={pattern}
            onClose={() => setCoachOpen(false)}
            onInput={setCoachInput}
            onSend={(text) => void sendCoach(text)}
            onGenerate={(request) => void generatePattern(request)}
            onVoice={startVoice}
            onReadAloud={() => setReadAloud((value) => !value)}
            onExplain={() => void sendCoach(pattern ? "Explain this generated Rhythm." : "Why did you recommend this Session?")}
          />
        )}
      </div>
    </div>
  );
}
