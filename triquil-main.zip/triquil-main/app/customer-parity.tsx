"use client";

import { useState, type FormEvent } from "react";
import { device, sessions, type CustomPattern, type Session, type SessionHistory } from "@/lib/demo-data";

export type CustomerView =
  | "home" | "history" | "custom" | "profile"
  | "treatment" | "favorites" | "custom-form" | "user-info" | "device"
  | "members" | "subscription" | "notifications" | "firmware" | "faq"
  | "support" | "privacy" | "terms" | "learn-more";

export type EntryStep = "language" | "welcome" | "learn-more" | "auth" | "create-profile" | "complete";

export function EntryFlow({ onComplete }: { onComplete: () => void }) {
  const [step, setStep] = useState<EntryStep>("language");
  const [slide, setSlide] = useState(0);
  const [authTab, setAuthTab] = useState<"signin" | "signup">("signin");
  const slides = [
    { icon: "⌁", title: "Welcome to TriQuil", copy: "A calm, app-connected companion for deliberate wellness Sessions." },
    { icon: "◌", title: "Seamless Device Pairing", copy: "Connect your TriQuil by Bluetooth and keep device details close at hand." },
    { icon: "△", title: "Ready to Get Started?", copy: "Explore Sessions, build custom Rhythms, and follow your progress." },
  ];
  const finish = () => { localStorage.setItem("triquil-onboarded", "true"); onComplete(); };

  if (step === "language") return (
    <div className="entry-screen" data-screen="LanguageSelection">
      <div className="entry-mark">BC</div><p className="section-label">WELCOME</p><h1>Choose your language</h1>
      <p>Choose your country or region and preferred language.</p>
      <label>Country / Region<select defaultValue="Canada"><option>Canada</option><option>United States</option><option>United Kingdom</option></select></label>
      <label>Language<select defaultValue="English"><option>English</option><option>French</option><option>Spanish</option></select></label>
      <button className="primary-button full-button" onClick={() => setStep("welcome")}>Continue</button>
    </div>
  );

  if (step === "welcome") return (
    <div className="entry-screen onboarding-screen" data-screen="WelcomeOnboarding">
      <button className="entry-skip" onClick={() => setStep("auth")}>Skip Introduction</button>
      <div className="onboarding-art"><span>{slides[slide].icon}</span></div>
      <p className="section-label">TRIQUIL</p><h1>{slides[slide].title}</h1><p>{slides[slide].copy}</p>
      <div className="carousel-dots" aria-label={`Slide ${slide + 1} of 3`}>{slides.map((_, index) => <button key={index} className={index === slide ? "active" : ""} onClick={() => setSlide(index)} aria-label={`Show slide ${index + 1}`} />)}</div>
      {slide < 2 ? <button className="primary-button full-button" onClick={() => setSlide((value) => value + 1)}>Next</button> : <button className="primary-button full-button" onClick={() => setStep("auth")}>Get Started</button>}
      <button className="text-button" onClick={() => setStep("learn-more")}>Learn More</button>
    </div>
  );

  if (step === "learn-more") return <LearnMoreScreen onBack={() => setStep("welcome")} />;

  if (step === "create-profile") return (
    <form className="entry-screen" data-screen="CreateProfile" onSubmit={(event) => { event.preventDefault(); finish(); }}>
      <button type="button" className="back-button" onClick={() => setStep("auth")}>← Back</button><p className="section-label">YOUR PROFILE</p><h1>Create Profile</h1>
      <div className="two-fields"><label>First Name<input required defaultValue="Alex" /></label><label>Last Name<input required defaultValue="Rivera" /></label></div>
      <label>Phone<input required type="tel" placeholder="(555) 123-4567" /></label>
      <fieldset className="plan-picker"><legend>Select a subscription plan</legend><label><input type="radio" name="plan" defaultChecked /> Free</label><label><input type="radio" name="plan" /> TriQuil+ Monthly · $9.99</label><label><input type="radio" name="plan" /> TriQuil+ Yearly · $79.99</label></fieldset>
      <button className="primary-button full-button" type="submit">Create Profile</button>
    </form>
  );

  return (
    <div className="entry-screen auth-screen" data-screen={authTab === "signin" ? "SignIn" : "SignUp"}>
      <button className="back-button" onClick={() => setStep("welcome")}>← Back</button><div className="entry-mark">BC</div><h1>Welcome back</h1>
      <div className="auth-tabs"><button className={authTab === "signin" ? "active" : ""} onClick={() => setAuthTab("signin")}>Sign In</button><button className={authTab === "signup" ? "active" : ""} onClick={() => setAuthTab("signup")}>Sign Up</button></div>
      <label>Email<input type="email" required placeholder="alex@example.com" /></label><label>Password<input type="password" required placeholder="At least 8 characters" /></label>
      {authTab === "signup" && <><label>Confirm Password<input type="password" required /></label><label className="check-row"><input type="checkbox" required /> I agree to the Terms of Service and Privacy Policy.</label></>}
      {authTab === "signin" && <button className="forgot-button">Forgot password?</button>}
      <button className="primary-button full-button" onClick={() => authTab === "signup" ? setStep("create-profile") : finish()}>{authTab === "signin" ? "Sign in with Email" : "Create Profile"}</button>
      <div className="auth-divider"><span>or continue with</span></div><button className="social-button">G&nbsp; Continue with Google</button><button className="social-button">●&nbsp; Continue with Apple</button>
      <small>Your data is protected in transit and at rest.</small>
    </div>
  );
}

export function SubScreenHeader({ title, eyebrow, onBack }: { title: string; eyebrow: string; onBack: () => void }) {
  return <div className="subscreen-header"><button className="back-button" onClick={onBack}>← Back</button><p className="section-label">{eyebrow}</p><h1>{title}</h1></div>;
}

export function TreatmentDetailsScreen({ session, connected, favorite, onBack, onFavorite, onStart }: { session: Session; connected: boolean; favorite: boolean; onBack: () => void; onFavorite: () => void; onStart: () => void }) {
  const [intensity, setIntensity] = useState(session.intensity);
  const [duration, setDuration] = useState(Math.min(session.duration, 20));
  return <div className="screen detail-screen" data-screen="TreatmentDetails">
    <SubScreenHeader title={session.name} eyebrow="TREATMENT DETAILS" onBack={onBack} />
    <section className="detail-hero"><span className="detail-orbit">◉</span><p>{session.objective}</p><button className={`heart-button ${favorite ? "active" : ""}`} onClick={onFavorite} aria-label={favorite ? "Remove from favorites" : "Add to favorites"}>♥</button></section>
    <section className="detail-card"><h2>Rhythm details</h2><dl><div><dt>Pattern</dt><dd>{session.pattern}</dd></div><div><dt>Pause time</dt><dd>1,000 ms</dd></div><div><dt>Division per cycle</dt><dd>3 independent tracks</dd></div><div><dt>Device status</dt><dd>{connected ? "Connected" : "Not connected"}</dd></div><div><dt>Treatment status</dt><dd>Ready</dd></div></dl></section>
    <section className="detail-card"><h2>Enabled motors</h2><div className="motor-grid">{(["P6", "LU9", "H7"] as const).map((motor) => <span className={session.motors.includes(motor) ? "enabled" : ""} key={motor}><strong>{motor}</strong><small>{session.motors.includes(motor) ? "Enabled" : "Off"}</small></span>)}</div></section>
    <section className="detail-card controls-card"><label>Vibration intensity <strong>{intensity}%</strong><input type="range" min="1" max="100" value={intensity} onChange={(event) => setIntensity(Number(event.target.value))} /></label><label>Duration <strong>{duration} min</strong><input type="range" min="1" max="20" value={duration} onChange={(event) => setDuration(Number(event.target.value))} /></label></section>
    <div className="detail-actions"><button className="primary-button" onClick={onStart}>Start</button><button className="secondary-button" disabled>Pause</button><button className="secondary-button" disabled>Stop</button></div>
  </div>;
}

export function FavoritesScreen({ favorites, onBack, onToggle, onPlay }: { favorites: string[]; onBack: () => void; onToggle: (name: string) => void; onPlay: (name: string) => void }) {
  const items = sessions.filter((session) => favorites.includes(session.name));
  return <div className="screen" data-screen="Favorites"><SubScreenHeader title="My Favorites" eyebrow="SAVED SESSIONS" onBack={onBack} /><div className="favorite-list">{items.length ? items.map((session) => <article className="favorite-card" key={session.name}><span className="session-icon">◉</span><div><h2>{session.name}</h2><p>{session.objective}</p></div><button className="heart-button active" onClick={() => onToggle(session.name)} aria-label={`Remove ${session.name} from favorites`}>♥</button><button className="restart-button" onClick={() => onPlay(session.name)} aria-label={`Play ${session.name}`}>▶</button></article>) : <div className="empty-state"><span>♡</span><h2>No favorites yet</h2><p>Open a treatment and tap the heart to save it here.</p></div>}</div></div>;
}

export function CustomTreatmentForm({ onBack, onCreate }: { onBack: () => void; onCreate: (pattern: CustomPattern) => void }) {
  const submit = (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault(); const data = new FormData(event.currentTarget); const intensity = Number(data.get("intensity"));
    onCreate({ name: String(data.get("name")), goal: "custom", objective: String(data.get("objective")), duration: Number(data.get("duration")), intensity, level: intensity <= 25 ? "Gentle" : intensity >= 45 ? "Strong" : "Balanced", why: String(data.get("description")), timingUnitMs: 10, pauseMs: Number(data.get("pause")), loopCount: Number(data.get("cycles")), source: "approved", tracks: (["P6", "LU9", "H7"] as const).map((actuator) => ({ actuator, steps: [{ amplitude: Number(data.get(`${actuator}-power`)), durationBeats: Number(data.get("step-time")) / 10 }] })) });
  };
  return <form className="screen parity-form" data-screen="CustomTreatmentForm" onSubmit={submit}><SubScreenHeader title="Add Custom Treatment" eyebrow="RHYTHM BUILDER" onBack={onBack} /><label>Name<input name="name" required defaultValue="My Calm Rhythm" /></label><label>Objective<input name="objective" required defaultValue="Create a deliberate quiet pause" /></label><label>Description<textarea name="description" required rows={3} defaultValue="A custom three-point vibration Rhythm." /></label><div className="two-fields"><label>Intensity (%)<input name="intensity" type="number" min="1" max="100" defaultValue="30" /></label><label>Duration<input name="duration" type="number" min="1" max="20" defaultValue="10" /></label></div><div className="two-fields"><label>Pause (ms)<input name="pause" type="number" min="0" defaultValue="1000" /></label><label>Division / cycles<input name="cycles" type="number" min="1" defaultValue="200" /></label></div><label>Step timing (ms, 10 ms beats)<input name="step-time" type="number" min="10" step="10" defaultValue="1000" /></label><fieldset className="motor-settings"><legend>Motor settings</legend>{(["P6", "LU9", "H7"] as const).map((motor) => <label key={motor}><span><input type="checkbox" defaultChecked /> {motor}</span><span>Power / amplitude <input name={`${motor}-power`} type="number" min="0" max="100" defaultValue="30" /></span></label>)}</fieldset><label className="check-row"><input type="checkbox" /> Treatment LED</label><button className="primary-button full-button" type="submit">Create Treatment</button></form>;
}

const faqCategories = ["General", "About TriQuil Device", "TriQuil Triangle", "Treatment and Device Usage", "Account and Login", "Subscription", "Member Management", "Notifications and Billing"];

export function ProfileSubScreen({ view, onBack, onReplay }: { view: CustomerView; onBack: () => void; onReplay: () => void }) {
  const [saved, setSaved] = useState(false);
  const headers: Partial<Record<CustomerView, [string, string]>> = { "user-info": ["User Information", "PROFILE"], device: ["Device", "TRIQUIL"], members: ["Manage Members", "FAMILY"], subscription: ["Manage Subscription", "TRIQUIL+"], notifications: ["Notification Settings", "PREFERENCES"], firmware: ["Firmware", "DEVICE SOFTWARE"], faq: ["Frequently Asked Questions", "HELP CENTER"], support: ["Help & Support", "WE’RE HERE TO HELP"], privacy: ["Privacy Policy", "LEGAL"], terms: ["Terms of Service", "LEGAL"], "learn-more": ["Learn More", "ABOUT TRIQUIL"] };
  const [title, eyebrow] = headers[view] || ["Profile", "ACCOUNT"];
  return <div className="screen profile-subscreen" data-screen={`Profile-${view}`}><SubScreenHeader title={title} eyebrow={eyebrow} onBack={onBack} />
    {view === "user-info" && <section className="info-card"><div className="profile-avatar large">AR</div><dl><div><dt>Name</dt><dd>Alex Rivera</dd></div><div><dt>Email</dt><dd>alex@example.com</dd></div><div><dt>Password</dt><dd>••••••••••</dd></div></dl><button className="secondary-button full-button" onClick={onReplay}>Replay Introduction</button></section>}
    {view === "device" && <section className="info-card"><div className="device-summary"><span>⌁</span><div><h2>TriQuil</h2><p>Connected · {device.battery}% battery</p></div></div><dl><div><dt>Serial number</dt><dd>{device.serialNumber}</dd></div><div><dt>Firmware</dt><dd>{device.firmware}</dd></div><div><dt>Hardware</dt><dd>Haptic prototype</dd></div></dl></section>}
    {view === "firmware" && <section className="info-card centered-card"><span className="large-icon">↟</span><h2>Firmware {device.firmware}</h2><p>Your TriQuil software is up to date.</p><button className="secondary-button">Check for Updates</button></section>}
    {view === "members" && <MembersPanel />}
    {view === "subscription" && <SubscriptionPanel />}
    {view === "notifications" && <form className="settings-list" onSubmit={(event) => { event.preventDefault(); setSaved(true); }}>{["Session reminders", "Billing / subscription alerts", "Daily reminder"].map((label) => <label key={label}><span><strong>{label}</strong><small>Keep this notification enabled</small></span><input type="checkbox" defaultChecked /></label>)}<label className="quiet-hours"><span><strong>Quiet hours</strong><small>Do not send reminders</small></span><span><input type="time" defaultValue="22:00" /> to <input type="time" defaultValue="07:00" /></span></label><button className="primary-button full-button">Save Changes</button>{saved && <p className="success-note">Notification settings saved.</p>}</form>}
    {view === "faq" && <div className="accordion-list">{faqCategories.map((category) => <details key={category}><summary>{category}<span>+</span></summary><p>Find clear guidance about {category.toLowerCase()} in the TriQuil app and User Manual.</p></details>)}</div>}
    {view === "support" && <SupportForm />}
    {view === "privacy" && <LegalCopy title="Privacy Policy" />}
    {view === "terms" && <LegalCopy title="Terms of Service" />}
    {view === "learn-more" && <LearnMoreBody />}
  </div>;
}

function MembersPanel() { const [open, setOpen] = useState(false); return <><div className="member-list"><article><span className="member-avatar">AR</span><div><h2>Alex Rivera</h2><p>Primary member · alex@example.com</p></div></article><article><span className="member-avatar">JR</span><div><h2>Jordan Rivera</h2><p>Secondary member · (555) 222-0199</p></div></article></div><button className="primary-button full-button" onClick={() => setOpen((value) => !value)}>+ Add Member</button>{open && <form className="inline-form" onSubmit={(event) => { event.preventDefault(); setOpen(false); }}><div className="image-placeholder">Add profile image</div><div className="two-fields"><label>First Name<input required /></label><label>Last Name<input required /></label></div><label>Email<input type="email" required /></label><label>Phone<input type="tel" required /></label><button className="primary-button full-button">Add Member</button></form>}</>; }

function SubscriptionPanel() { const plans = [{ name: "Free", price: "$0", users: "0 secondary users" }, { name: "TriQuil+ Monthly", price: "$9.99 / month", users: "Up to 10 secondary users" }, { name: "TriQuil+ Yearly", price: "$79.99 / year", users: "Up to 10 secondary users" }]; return <><section className="current-plan"><p className="section-label">CURRENT PLAN</p><h2>TriQuil+ Monthly</h2><p>$9.99 per month · renews Oct 15, 2026</p><button className="text-button">Cancel Subscription</button></section><div className="plan-list">{plans.map((plan) => <article key={plan.name}><div><h2>{plan.name}</h2><p>{plan.price} · {plan.users}</p></div><button className="secondary-button">Upgrade</button></article>)}</div><section className="usage-grid"><div><strong>2</strong><small>Members</small></div><div><strong>1</strong><small>Custom treatment</small></div><div><strong>24</strong><small>History saved</small></div></section><section className="info-card"><h2>Billing history</h2><dl><div><dt>Last payment</dt><dd>Sep 15 · $9.99</dd></div><div><dt>Next payment</dt><dd>Oct 15 · $9.99</dd></div><div><dt>Payment method</dt><dd>Visa ending 4242</dd></div></dl><button className="secondary-button full-button">Manage Payment Method</button></section></>; }

function SupportForm() { const [sent, setSent] = useState(false); return <><button className="secondary-button full-button">View Frequently Asked Questions</button><form className="parity-form support-form" onSubmit={(event) => { event.preventDefault(); setSent(true); }}><label>Name<input required defaultValue="Alex Rivera" /></label><label>Email<input required type="email" defaultValue="alex@example.com" /></label><label>Subject<input required placeholder="How can we help?" /></label><label>Message<textarea required rows={5} placeholder="Tell us what happened..." /></label><button className="primary-button full-button">Send Message</button>{sent && <p className="success-note">Message sent. Support will respond within 24 hours.</p>}</form></>; }

function LegalCopy({ title }: { title: string }) { return <article className="legal-copy"><p>Last updated September 2026</p><h2>{title === "Privacy Policy" ? "Your information and choices" : "Using TriQuil"}</h2><p>Auvara Wellness uses the information needed to provide accounts, device connection, Sessions, subscriptions, and support. Information should be collected with consent and protected in transit and at rest.</p><h2>General wellness</h2><p>TriQuil is a vibration-only general-wellness product. It does not diagnose or treat disease and does not measure physiological readings.</p><h2>Contact</h2><p>Contact Auvara Wellness support with questions about this policy or your account.</p></article>; }

function LearnMoreBody() { return <div className="learn-sections"><section><span>⌁</span><h2>What is TriQuil?</h2><p>A vibration-only inner-wrist wearable for deliberate relaxation, focus, sleep preparation, and recovery Sessions.</p></section><section><span>◌</span><h2>How and Why It Works</h2><p>Three independently controlled actuators create pulses, sweeps, and rotating spatial Rhythms.</p></section><section><span>△</span><h2>What is TriQuil Triangle?</h2><p>The three inner-wrist points used by TriQuil.</p><div className="point-grid"><strong>P6<small>Motor A</small></strong><strong>LU9<small>Motor B</small></strong><strong>H7<small>Motor C</small></strong></div></section><section><span>♡</span><h2>Why Choose TriQuil?</h2><p>Choose predefined Sessions, create custom Rhythms, and use explicit feedback to personalize future recommendations.</p></section></div>; }
export function LearnMoreScreen({ onBack }: { onBack: () => void }) { return <div className="entry-screen learn-entry" data-screen="LearnMore"><button className="back-button" onClick={onBack}>← Back</button><p className="section-label">DISCOVER</p><h1>Learn More</h1><LearnMoreBody /></div>; }

export function DashboardParityLinks({ onFavorites, onCustom }: { onFavorites: () => void; onCustom: () => void }) { return <section className="dashboard-shortcuts"><button onClick={onFavorites}><span>♥</span><strong>My Favorites</strong><small>Saved Sessions</small></button><button onClick={onCustom}><span>✦</span><strong>Custom Treatments</strong><small>Build your Rhythm</small></button></section>; }

export function MiniSessionPlayer({ name, paused, onOpen, onPause, onStop }: { name: string; paused: boolean; onOpen: () => void; onPause: () => void; onStop: () => void }) { return <div className="mini-player" data-screen="MiniSessionPlayer"><button className="mini-main" onClick={onOpen}><span className="mini-pulse">◉</span><span><strong>{name}</strong><small>{paused ? "Paused" : "Session playing"}</small></span></button><button onClick={onPause} aria-label={paused ? "Resume mini player" : "Pause mini player"}>{paused ? "▶" : "Ⅱ"}</button><button onClick={onStop} aria-label="Stop mini player">■</button></div>; }

export function exportHistory(history: SessionHistory[]) { const content = ["Session,Date,Rating", ...history.map((item) => `"${item.sessionName}","${item.completedAt}",${item.rating || ""}`)].join("\n"); const link = document.createElement("a"); link.href = URL.createObjectURL(new Blob([content], { type: "text/csv" })); link.download = "triquil-history.csv"; link.click(); URL.revokeObjectURL(link.href); }
