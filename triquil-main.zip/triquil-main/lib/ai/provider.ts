import { OllamaProvider } from "./ollama";
import { OpenRouterProvider } from "./openrouter";
import type { AIProvider } from "./types";

export function getAIProvider(): AIProvider {
  return process.env.AI_PROVIDER?.toLowerCase() === "openrouter"
    ? new OpenRouterProvider()
    : new OllamaProvider();
}