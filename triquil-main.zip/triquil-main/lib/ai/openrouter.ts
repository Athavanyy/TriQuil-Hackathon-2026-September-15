import { AIProviderError, type AIProvider, type AIRequest } from "./types";

const OPENROUTER_URL = "https://openrouter.ai/api/v1/chat/completions";

type OpenRouterResponse = {
  choices?: Array<{ message?: { content?: string } }>;
  error?: { message?: string };
};

export class OpenRouterProvider implements AIProvider {
  readonly name = "openrouter" as const;

  async chat({ messages, temperature = 0.2, responseFormat = "text" }: AIRequest) {
    const apiKey = process.env.OPENROUTER_API_KEY;
    const model = process.env.OPENROUTER_MODEL;

    if (!apiKey || !model) {
      throw new AIProviderError("OpenRouter is not configured.");
    }

    let response: Response;
    try {
      response = await fetch(OPENROUTER_URL, {
        method: "POST",
        headers: {
          Authorization: `Bearer ${apiKey}`,
          "Content-Type": "application/json",
          "X-Title": "TriQuil AI Prototype",
        },
        body: JSON.stringify({
          model,
          messages,
          temperature,
          response_format: responseFormat === "json" ? { type: "json_object" } : undefined,
        }),
        signal: AbortSignal.timeout(20_000),
      });
    } catch (error) {
      throw new AIProviderError("Unable to reach the OpenRouter provider.", error);
    }

    let payload: OpenRouterResponse;
    try {
      payload = await response.json() as OpenRouterResponse;
    } catch (error) {
      throw new AIProviderError("OpenRouter returned an invalid response.", error);
    }

    if (!response.ok) {
      throw new AIProviderError(payload.error?.message || `OpenRouter returned ${response.status}.`);
    }

    const content = payload.choices?.[0]?.message?.content;
    if (!content || typeof content !== "string") {
      throw new AIProviderError("OpenRouter returned an empty response.");
    }

    return content;
  }
}