export type AIMessage = {
  role: "system" | "user" | "assistant";
  content: string;
};

export type AIRequest = {
  messages: AIMessage[];
  temperature?: number;
  responseFormat?: "json" | "text";
};

export type AIProviderName = "ollama" | "openrouter";

export interface AIProvider {
  readonly name: AIProviderName;
  chat(request: AIRequest): Promise<string>;
}

export class AIProviderError extends Error {
  constructor(message: string, public readonly cause?: unknown) {
    super(message);
    this.name = "AIProviderError";
  }
}