import { AIProviderError, type AIProvider, type AIRequest } from "./types";

const DEFAULT_OLLAMA_URL = "http://127.0.0.1:11434";
const DEFAULT_OLLAMA_MODEL = "llama3.2";

export class OllamaProvider implements AIProvider {
  readonly name = "ollama" as const;

  private readonly baseUrl =
    process.env.OLLAMA_BASE_URL?.replace(/\/$/, "") ?? DEFAULT_OLLAMA_URL;
  private readonly model = process.env.OLLAMA_MODEL ?? DEFAULT_OLLAMA_MODEL;

  async chat({ messages, temperature = 0.2, responseFormat = "text" }: AIRequest) {
    let response: Response;

    try {
      response = await fetch(`${this.baseUrl}/api/chat`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          model: this.model,
          messages,
          stream: false,
          format: responseFormat === "json" ? "json" : undefined,
          options: { temperature },
        }),
        signal: AbortSignal.timeout(15_000),
      });
    } catch (error) {
      throw new AIProviderError("Unable to reach the Ollama provider.", error);
    }

    if (!response.ok) {
      throw new AIProviderError(
        `Ollama returned ${response.status}: ${await response.text()}`,
      );
    }

    const payload = (await response.json()) as { message?: { content?: string } };
    const content = payload.message?.content;

    if (!content) {
      throw new AIProviderError("Ollama returned an empty response.");
    }

    return content;
  }
}
