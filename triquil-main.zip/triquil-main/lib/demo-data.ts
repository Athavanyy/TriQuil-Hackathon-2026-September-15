export type Level = "Gentle" | "Balanced" | "Strong";
export type Actuator = "P6" | "LU9" | "H7";
export type PatternStep = { amplitude: number; durationBeats: number };
export type PatternTrack = { actuator: Actuator; steps: PatternStep[] };
export type CustomPattern = {
  name: string;
  goal: string;
  objective: string;
  duration: number;
  intensity: number;
  level: Level;
  why: string;
  timingUnitMs: 10;
  pauseMs: number;
  loopCount: number;
  tracks: PatternTrack[];
  source: "ai" | "approved";
};
export type Session = { name: string; objective: string; description: string; duration: number; intensity: number; pattern: string; motors: Actuator[] };
export type SessionHistory = {
  id: string;
  sessionName: string;
  completedAt: string;
  duration: number;
  goal: string;
  level: Level;
  intensity: number;
  rating?: number;
  comfort?: string;
  custom: boolean;
  generated: boolean;
};
export type SessionFeedback = { sessionName: string; rating: number; comfort?: string; note?: string };

export const sessions: Session[] = [
  { name: "Relaxation Session", objective: "Ease into a quiet pause", description: "A spacious three-point Rhythm for everyday relaxation.", duration: 10, intensity: 22, pattern: "Gentle rotating pulses", motors: ["P6", "LU9", "H7"] },
  { name: "Calming Breath", objective: "Settle into a slower rhythm", description: "A gentle, paced Rhythm for a quiet reset.", duration: 5, intensity: 24, pattern: "Slow, rhythmic pulsations", motors: ["P6", "LU9"] },
  { name: "Focus Flow", objective: "Create a clear start to focused time", description: "A steady spatial Rhythm for a deliberate Session.", duration: 10, intensity: 32, pattern: "Alternating spatial sweep", motors: ["P6", "LU9", "H7"] },
  { name: "Sleep Support", objective: "Prepare for a restful evening", description: "A low-intensity Rhythm for winding down before sleep.", duration: 15, intensity: 18, pattern: "Soft, descending pulses", motors: ["LU9", "H7"] },
  { name: "Recovery Pulse", objective: "Take a measured pause after activity", description: "A considered pulse pattern for a post-activity reset.", duration: 8, intensity: 28, pattern: "Repeating three-point pulse", motors: ["P6", "H7"] },
];

const todayAt = (hour: number, minute: number, dayOffset = 0) => {
  const date = new Date();
  date.setDate(date.getDate() + dayOffset);
  date.setHours(hour, minute, 0, 0);
  return date.toISOString();
};

export const initialHistory: SessionHistory[] = [
  { id: "demo-calm", sessionName: "Calming Breath", completedAt: todayAt(8, 40), duration: 5, goal: "Relax", level: "Gentle", intensity: 24, rating: 4, comfort: "comfortable", custom: false, generated: false },
  { id: "demo-focus", sessionName: "Focus Flow", completedAt: todayAt(10, 15, -1), duration: 10, goal: "Focus", level: "Balanced", intensity: 32, rating: 5, comfort: "comfortable", custom: false, generated: false },
  { id: "demo-sleep", sessionName: "Sleep Support", completedAt: todayAt(21, 30, -3), duration: 15, goal: "Better Sleep", level: "Gentle", intensity: 18, rating: 4, comfort: "comfortable", custom: false, generated: false },
];

export function formatHistoryDate(value: string, includeDate = true) {
  const date = new Date(value);
  if (Number.isNaN(date.getTime())) return value;
  const time = new Intl.DateTimeFormat("en-US", { hour: "numeric", minute: "2-digit" }).format(date);
  if (!includeDate) return time;
  const today = new Date();
  const yesterday = new Date(today);
  yesterday.setDate(today.getDate() - 1);
  const key = date.toDateString();
  const day = key === today.toDateString() ? "Today" : key === yesterday.toDateString() ? "Yesterday" : new Intl.DateTimeFormat("en-US", { month: "short", day: "numeric" }).format(date);
  return `${day}, ${time}`;
}

export const device = { serialNumber: "BC-2408-0184", firmware: "1.4.2", battery: 78, status: "Connected" as const };

export const durationOptions = [5, 10, 15, 20] as const;
export const levels: Record<Level, number> = { Gentle: 20, Balanced: 35, Strong: 50 };

export function validatePattern(pattern: CustomPattern): CustomPattern {
  if (!pattern || typeof pattern !== "object") throw new Error("Pattern is outside TriQuil limits.");
  const validText = [pattern.name, pattern.goal, pattern.objective, pattern.why].every((value) => typeof value === "string" && value.trim().length > 0);
  const validLevel = (["Gentle", "Balanced", "Strong"] as const).includes(pattern.level);
  const validSource = pattern.source === "ai" || pattern.source === "approved";
  const validTracks = Array.isArray(pattern.tracks) && pattern.tracks.length === 3 && pattern.tracks.map((track) => track?.actuator).join(",") === "P6,LU9,H7";
  const validDuration = durationOptions.includes(pattern.duration as (typeof durationOptions)[number]);
  const validIntensity = Number.isInteger(pattern.intensity) && pattern.intensity >= 1 && pattern.intensity <= 100;
  const validTiming = pattern.timingUnitMs === 10 && Number.isInteger(pattern.pauseMs) && pattern.pauseMs >= 0 && pattern.pauseMs <= 60_000 && Number.isInteger(pattern.loopCount) && pattern.loopCount >= 1 && pattern.loopCount <= 1_000;
  const validSteps = validTracks && pattern.tracks.every((track) => Array.isArray(track.steps) && track.steps.length >= 1 && track.steps.length <= 40 && track.steps.every((step) => step && Number.isInteger(step.amplitude) && step.amplitude >= 0 && step.amplitude <= 100 && Number.isInteger(step.durationBeats) && step.durationBeats >= 1 && step.durationBeats <= 6_000));
  if (!validText || !validLevel || !validSource || !validTracks || !validDuration || !validIntensity || !validTiming || !validSteps) {
    throw new Error("Pattern is outside TriQuil limits.");
  }
  return pattern;
}